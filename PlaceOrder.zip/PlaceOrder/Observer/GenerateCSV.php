<?php

namespace Vdcstore\PlaceOrder\Observer;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Event\ObserverInterface;

class GenerateCSV implements ObserverInterface
{
       protected $_objectManager;
       private $logger;
       private $productFactory;
       protected $_customerFactory;
       protected $_directory;


  public function __construct(
     Context $context,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Customer\Model\CustomerFactory $customerFactory
    \Magento\Framework\ObjectManagerInterface $objectManager,
    \Psr\Log\LoggerInterface $logger,
    \Magento\Catalog\Model\ProductFactory $productFactory
  ) {
      $this->_customerFactory = $customerFactory;
        $this->_directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        parent::__construct($context);
      $this->_objectManager = $objectManager;
      $this->logger = $logger;
      $this->productFactory = $productFactory;
  }

  public function execute(\Magento\Framework\Event\Observer $observer)
  {
    // $order = $observer->getEvent()->getOrder();
    // $order_id = $order->getIncrementId();
    // $this->logger->info($order_id);
    // $this->logger->info("observer working");  
    
       // $this->_directory->create('export');

        
       //  $collection = $this->_customerFactory->create()->getCollection();
       //  foreach ($collection as $customer) {
       //      $customerData = [];
       //      $customerData[] = $customer->getId();
       //      $customerData[] = $customer->getName();
       //      $customerData[] = $customer->getEmail();
       //      $stream->writeCsv($customerData);
        }

  }
}